<?php

require_once 'Animal.php';
require_once 'Cachorro.php';
require_once 'Gato.php';
require_once 'Adotante.php';

$animal = new Animal("Biscoito", "Réptil", 4, "Macho", 15, "Listrado", "disponível", false);
$animal->exibirFicha();
echo "<hr>";

$cachorro = new Cachorro("Nala", "vira lata", "médio", 5, false, true, true, false);
$cachorro->exibirCachorro();
echo "<hr>";

$gato = new Gato("canela", "pouco pelo", true, 2, true, true, false, false);
$gato->exibirGato();
echo "<hr>";

$adotante = new Adotante("Ana Luiza", 17, "(51) 999806282", "analureismoreira07@gmail.com", "Av Bento Gonçalves 1515", true, "Sim");
$adotante->adotarAnimal($gato);
$adotante->exibirAdotante();
echo "<hr>";

$adotante->resumoAdotante();