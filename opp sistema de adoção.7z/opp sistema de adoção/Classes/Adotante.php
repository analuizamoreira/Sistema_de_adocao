<?php

class Adotante {
    public $nome;
    public $idade;
    public $telefone;
    public $email;
    public $endereco;
    public $temOutrosAnimais;
    public $experienciaComPets;
    public $animalAdotado;

    public function __construct($nome, $idade, $telefone, $email, $endereco, $temOutrosAnimais = false, $experienciaComPets = 'Não', $animalAdotado = null) {
        $this->nome = $nome;
        $this->idade = $idade;
        $this->telefone = $telefone;
        $this->email = $email;
        $this->endereco = $endereco;
        $this->temOutrosAnimais = $temOutrosAnimais;
        $this->experienciaComPets = $experienciaComPets;
        $this->animalAdotado = $animalAdotado;
    }

    public function exibirAdotante() {
        echo "Nome: " . $this->nome . "<br>";
        echo "Idade: " . $this->idade . "<br>";
        echo "Telefone: " . $this->telefone . "<br>";
        echo "E-mail: " . $this->email . "<br>";
        echo "Endereço: " . $this->endereco . "<br>";
        echo "Tem outros animais: " . ($this->temOutrosAnimais ? "Sim" : "Não") . "<br>";
        echo "Experiência com pets: " . $this->experienciaComPets . "<br>";
        if ($this->animalAdotado) {
            echo "Animal adotado: " . $this->animalAdotado->nome . "<br>";
        } else {
            echo "Nenhum animal adotado<br>";
        }
    }

    public function adotarAnimal($animal) {
        $this->animalAdotado = $animal;
    }

    public function verificarIdade() {
        return $this->idade >= 18 ? "Pode adotar" : "Não tem idade mínima para adoção";
    }

    public function temExperiencia() {
        if (is_string($this->experienciaComPets)) {
            $exp = strtolower($this->experienciaComPets);
            return ($exp == 'sim' || !empty($exp)) ? "Tem experiência" : "Não tem experiência";
        }
        return $this->experienciaComPets ? "Tem experiência" : "Não tem experiência";
    }

    public function listarContato() {
        echo "Telefone: " . $this->telefone . " | E-mail: " . $this->email . "<br>";
    }

    public function verificarOutrosAnimais() {
        return $this->temOutrosAnimais ? "Possui outros pets" : "Não possui outros pets";
    }

    public function cancelarAdocao() {
        if ($this->animalAdotado) {
            $this->animalAdotado->alterarStatus('disponível');
            $this->animalAdotado = null;
        }
    }

    public function resumoAdotante() {
        echo "Nome: " . $this->nome;
        if ($this->animalAdotado) {
            echo " | Animal adotado: " . $this->animalAdotado->nome;
        }
        echo "<br>";
    }
}