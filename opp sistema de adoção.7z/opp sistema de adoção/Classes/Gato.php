<?php

class Gato {
    public $nome;
    public $pelagem;
    public $castrado;
    public $independente;
    public $vacinado;
    public $curioso;
    public $adoraColo;
    public $usaCaixaAreia;

    public function __construct($nome, $pelagem, $castrado = false, $independente = 5, $vacinado = false, $curioso = false, $adoraColo = false, $usaCaixaAreia = false) {
        $this->nome = $nome;
        $this->pelagem = $pelagem;
        $this->castrado = $castrado;
        $this->independente = $independente;
        $this->vacinado = $vacinado;
        $this->curioso = $curioso;
        $this->adoraColo = $adoraColo;
        $this->usaCaixaAreia = $usaCaixaAreia;
    }

    public function exibirGato() {
        echo "Nome: " . $this->nome . "<br>";
        echo "Pelagem: " . $this->pelagem . "<br>";
        echo "Castrado: " . ($this->castrado ? "Sim" : "Não") . "<br>";
        echo "Nível de independência: " . $this->independente . "<br>";
        echo "Vacinado: " . ($this->vacinado ? "Sim" : "Não") . "<br>";
        echo "Curioso: " . ($this->curioso ? "Sim" : "Não") . "<br>";
        echo "Adora colo: " . ($this->adoraColo ? "Sim" : "Não") . "<br>";
        echo "Sabe usar caixa de areia: " . ($this->usaCaixaAreia ? "Sim" : "Não") . "<br>";
    }

    public function castrar() {
        $this->castrado = true;
    }

    public function verificarPelagem() {
        return $this->pelagem;
    }

    public function atualizarIndependencia($grau) {
        if ($grau >= 1 && $grau <= 10) {
            $this->independente = $grau;
        }
    }

    public function vacinar() {
        $this->vacinado = true;
    }

    public function resumoGato() {
        $status = $this->castrado ? "Castrado" : "Não castrado";
        echo "Nome: " . $this->nome . " | Pelagem: " . $this->pelagem . " | Status: " . $status . "<br>";
    }

    public function ensinarCaixaAreia() {
        $this->usaCaixaAreia = true;
    }

    public function verificarContato() {
        return $this->adoraColo ? "Aceita colo" : "Aceita colo";
    }
}